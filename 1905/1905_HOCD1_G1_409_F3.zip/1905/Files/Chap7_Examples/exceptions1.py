# Exception Example
def print_age_in_days(years):
    print('Age in days is', 365.25 * int(years))

age = input('Enter your age: ')
print_age_in_days(age)
