"""
Exercise 2.1 Arithmetic and Numeric Types
Ex2_1.py
"""

print('This is exercise 2.1')

# Part A
num1 = '5'
num2 = '9'

# Part B
paris_temp = '25'
honolulu_temp = '81'
freezing = 32.0

# Part C
price = '199.95'

discount_small = .05
discount_med = .10
discount_big = .15


