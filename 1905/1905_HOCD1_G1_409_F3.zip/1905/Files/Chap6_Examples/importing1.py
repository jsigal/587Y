# Module Execution
import circles

print(circles)

# Module Attributes
rad = 1.0
print(circles.PI)
ar = circles.area(rad)
print('circle is radius {} area {}'.format(rad, ar))