# Namespace Corruption

import sys

def log(msg):
    print(msg, file=sys.stderr)
