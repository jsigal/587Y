# Add import statements at the top of the source code

toppings = ['pepperoni', 'cheese', 'ham', 'bacon',
            'mushrooms', 'peppers', 'onions', 'olives']

num_toppings = 3

# Create a for loop to process the iterator
