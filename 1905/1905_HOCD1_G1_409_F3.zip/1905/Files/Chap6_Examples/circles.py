PI = 3.14

def area(radius):
    return PI * radius ** 2

def diameter(radius):
    return radius * 2