# Namespace Corruption

from logger import *
log('test 1 error message')

from math import *
log('test 2 error message')