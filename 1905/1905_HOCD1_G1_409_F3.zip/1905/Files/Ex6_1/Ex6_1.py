"""
Exercise 6.1 Modules
Ex6_1.py
"""

flight_data = (221, 'HNL', 'HNL', '2022-01-03 08:30', '2022-01-03 15:40', 399.99, 2)

flight_attributes = ('flightnum', 'departcity', 'arrivecity', 'departdaytime',
                     'arrivedaytime', 'cost', 'code')

def main_pgm():
    print('This is main_pgm()')


if __name__ == '__main__':
    main_pgm()
